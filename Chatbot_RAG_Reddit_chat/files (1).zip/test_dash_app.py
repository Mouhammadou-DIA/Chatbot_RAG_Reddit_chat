"""
Tests pour l'application Reddit RAG Chatbot
"""

import pytest
import sys
from pathlib import Path

# Ajouter le répertoire parent au PYTHONPATH
sys.path.insert(0, str(Path(__file__).parent.parent))

# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def mock_rag_system():
    """Mock du système RAG pour les tests"""
    class MockRAG:
        def __init__(self):
            self.stats = {
                'total_queries': 0,
                'avg_search_time': 0,
                'cache_hits': 0
            }
            self.llm_enabled = False
        
        def optimized_search(self, query, top_k=3, **kwargs):
            """Recherche mockée"""
            self.stats['total_queries'] += 1
            
            return {
                'results': [
                    {
                        'text': f'Question: Mock question\n\nRéponse: Mock answer for {query}',
                        'similarity': 0.95,
                        'metadata': {'type': 'qa_pair'}
                    },
                    {
                        'text': f'Question: Another question\n\nRéponse: Another answer for {query}',
                        'similarity': 0.87,
                        'metadata': {'type': 'qa_pair'}
                    }
                ],
                'quality': {
                    'quality': 'excellent',
                    'confidence': 0.91,
                    'diversity': 0.75,
                    'coverage': 0.85,
                    'overall_score': 0.84
                },
                'timing': {
                    'search': 0.015,
                    'reranking': 0.005,
                    'total': 0.025
                }
            }
        
        def evaluate_result_quality(self, query, results):
            """Évaluation mockée"""
            return {
                'quality': 'good',
                'confidence': 0.85,
                'diversity': 0.70,
                'coverage': 0.80,
                'overall_score': 0.78
            }
        
        def get_statistics(self):
            """Statistiques mockées"""
            return {
                'total_queries': self.stats['total_queries'],
                'cache_hits': self.stats['cache_hits'],
                'cache_hit_rate': 0.0,
                'avg_search_time_ms': 25.0,
                'total_chunks': 50000,
                'total_conversations': 25000
            }
    
    return MockRAG()

@pytest.fixture
def app():
    """Fixture de l'application Dash"""
    # Import ici pour éviter les erreurs si le module n'existe pas
    try:
        from reddit_rag_dash_app import app as dash_app
        return dash_app
    except ImportError:
        pytest.skip("Module reddit_rag_dash_app non disponible")

# ============================================================================
# TESTS DE CONFIGURATION
# ============================================================================

class TestConfiguration:
    """Tests de la configuration"""
    
    def test_config_import(self):
        """Tester l'import de la configuration"""
        from config import Config, config
        
        assert Config is not None
        assert config is not None
    
    def test_config_values(self):
        """Tester les valeurs de configuration"""
        from config import Config
        
        # App config
        assert Config.App.TITLE == "Reddit RAG Chatbot"
        assert isinstance(Config.App.PORT, int)
        assert Config.App.PORT > 0
        
        # RAG config
        assert Config.RAG.DEFAULT_TOP_K >= Config.RAG.MIN_TOP_K
        assert Config.RAG.DEFAULT_TOP_K <= Config.RAG.MAX_TOP_K
        
        # LLM config
        assert Config.LLM.DEFAULT_TEMPERATURE >= Config.LLM.MIN_TEMPERATURE
        assert Config.LLM.DEFAULT_TEMPERATURE <= Config.LLM.MAX_TEMPERATURE
    
    def test_theme_config(self):
        """Tester la configuration des thèmes"""
        from config import Config
        
        theme = Config.Theme.CURRENT_THEME
        
        assert 'background' in theme
        assert 'primary' in theme
        assert 'success' in theme
        
        # Vérifier le format des couleurs
        assert theme['primary'].startswith('#') or theme['primary'].startswith('rgb')
    
    def test_config_summary(self):
        """Tester le résumé de configuration"""
        from config import Config
        
        summary = Config.get_summary()
        
        assert 'app' in summary
        assert 'rag' in summary
        assert 'llm' in summary
        assert 'theme' in summary

# ============================================================================
# TESTS DES COMPOSANTS UI
# ============================================================================

class TestUIComponents:
    """Tests des composants d'interface"""
    
    def test_create_header(self):
        """Tester la création de l'en-tête"""
        try:
            from reddit_rag_dash_app import create_header
            
            header = create_header()
            assert header is not None
        except ImportError:
            pytest.skip("Module non disponible")
    
    def test_create_sidebar(self):
        """Tester la création de la sidebar"""
        try:
            from reddit_rag_dash_app import create_sidebar
            
            sidebar = create_sidebar()
            assert sidebar is not None
        except ImportError:
            pytest.skip("Module non disponible")
    
    def test_create_chat_interface(self):
        """Tester la création de l'interface de chat"""
        try:
            from reddit_rag_dash_app import create_chat_interface
            
            chat = create_chat_interface()
            assert chat is not None
        except ImportError:
            pytest.skip("Module non disponible")

# ============================================================================
# TESTS DES UTILITAIRES
# ============================================================================

class TestUtilities:
    """Tests des fonctions utilitaires"""
    
    def test_format_rag_results(self):
        """Tester le formatage des résultats"""
        try:
            from reddit_rag_dash_app import format_rag_results
            
            results = [
                {
                    'text': 'Question: Test?\n\nRéponse: Answer',
                    'similarity': 0.95,
                    'metadata': {}
                }
            ]
            
            formatted = format_rag_results(results)
            
            assert isinstance(formatted, str)
            assert len(formatted) > 0
            assert 'Test?' in formatted or 'Answer' in formatted
        
        except ImportError:
            pytest.skip("Module non disponible")
    
    def test_format_empty_results(self):
        """Tester le formatage avec résultats vides"""
        try:
            from reddit_rag_dash_app import format_rag_results
            
            formatted = format_rag_results([])
            
            assert isinstance(formatted, str)
            assert 'Aucun' in formatted or 'trouvé' in formatted
        
        except ImportError:
            pytest.skip("Module non disponible")
    
    def test_create_message(self):
        """Tester la création de messages"""
        try:
            from reddit_rag_dash_app import create_message
            
            user_msg = create_message("user", "Test message")
            assert user_msg is not None
            
            assistant_msg = create_message("assistant", "Response")
            assert assistant_msg is not None
            
            system_msg = create_message("system", "Error", error=True)
            assert system_msg is not None
        
        except ImportError:
            pytest.skip("Module non disponible")

# ============================================================================
# TESTS D'INTÉGRATION
# ============================================================================

class TestIntegration:
    """Tests d'intégration"""
    
    def test_app_initialization(self, app):
        """Tester l'initialisation de l'application"""
        assert app is not None
        assert hasattr(app, 'layout')
        assert hasattr(app, 'callback')
    
    def test_app_layout(self, app):
        """Tester le layout de l'application"""
        layout = app.layout
        assert layout is not None
    
    @pytest.mark.skip(reason="Nécessite un serveur Dash actif")
    def test_app_server(self, app):
        """Tester le serveur de l'application"""
        # Ce test nécessiterait selenium ou requests-html
        pass

# ============================================================================
# TESTS DE PERFORMANCE
# ============================================================================

class TestPerformance:
    """Tests de performance"""
    
    def test_search_performance(self, mock_rag_system):
        """Tester la performance de recherche"""
        import time
        
        start = time.time()
        result = mock_rag_system.optimized_search("test query", top_k=3)
        elapsed = time.time() - start
        
        # La recherche mockée devrait être très rapide
        assert elapsed < 1.0
        assert result is not None
    
    def test_multiple_searches(self, mock_rag_system):
        """Tester plusieurs recherches"""
        import time
        
        queries = ["query1", "query2", "query3", "query4", "query5"]
        
        start = time.time()
        for query in queries:
            mock_rag_system.optimized_search(query)
        elapsed = time.time() - start
        
        # Toutes les recherches devraient prendre moins d'une seconde
        assert elapsed < 1.0
        assert mock_rag_system.stats['total_queries'] == len(queries)

# ============================================================================
# TESTS DE RÉGRESSION
# ============================================================================

class TestRegression:
    """Tests de régression"""
    
    def test_config_backward_compatibility(self):
        """Tester la rétrocompatibilité de la config"""
        from config import Config
        
        # Ces attributs doivent toujours exister
        required_attrs = [
            'App.TITLE',
            'App.PORT',
            'RAG.DEFAULT_TOP_K',
            'LLM.DEFAULT_TEMPERATURE',
            'Theme.CURRENT_THEME'
        ]
        
        for attr_path in required_attrs:
            parts = attr_path.split('.')
            obj = Config
            
            for part in parts:
                assert hasattr(obj, part), f"Attribut manquant: {attr_path}"
                obj = getattr(obj, part)

# ============================================================================
# TESTS DE VALIDATION
# ============================================================================

class TestValidation:
    """Tests de validation"""
    
    def test_config_validation(self):
        """Tester la validation de la configuration"""
        from config import validate_config
        
        # La validation ne devrait pas lever d'exception
        try:
            result = validate_config()
            # Le résultat peut être True ou False selon les fichiers présents
            assert isinstance(result, bool)
        except Exception as e:
            pytest.fail(f"Validation a échoué avec erreur: {e}")
    
    def test_input_sanitization(self):
        """Tester la sanitisation des entrées"""
        # Test basique de validation
        test_inputs = [
            ("Normal query", True),
            ("Query with numbers 123", True),
            ("Query with punctuation!?", True),
            ("", False),  # Vide
            (" ", False),  # Seulement espaces
        ]
        
        for input_text, should_be_valid in test_inputs:
            is_valid = len(input_text.strip()) > 0
            assert is_valid == should_be_valid, f"Échec pour: {input_text}"

# ============================================================================
# TESTS DE SÉCURITÉ
# ============================================================================

class TestSecurity:
    """Tests de sécurité"""
    
    def test_input_length_validation(self):
        """Tester la validation de longueur d'entrée"""
        from config import SecurityConfig
        
        max_length = SecurityConfig.MAX_INPUT_LENGTH
        
        # Entrée valide
        valid_input = "a" * (max_length - 1)
        assert len(valid_input) < max_length
        
        # Entrée trop longue
        invalid_input = "a" * (max_length + 1)
        assert len(invalid_input) > max_length
    
    def test_no_code_injection(self):
        """Tester la protection contre l'injection de code"""
        malicious_inputs = [
            "<script>alert('xss')</script>",
            "'; DROP TABLE users; --",
            "{{ 7*7 }}",
            "${7*7}",
        ]
        
        # Ces entrées ne devraient pas être exécutées
        for malicious in malicious_inputs:
            # Test basique - vérifier qu'elles sont traitées comme du texte
            assert isinstance(malicious, str)

# ============================================================================
# UTILITAIRES DE TEST
# ============================================================================

class TestUtils:
    """Utilitaires pour les tests"""
    
    @staticmethod
    def generate_mock_chat_history(n=5):
        """Générer un historique de chat mock"""
        history = []
        
        for i in range(n):
            history.append({
                "role": "user",
                "content": f"Question {i}",
                "timestamp": "2024-01-01T00:00:00"
            })
            history.append({
                "role": "assistant",
                "content": f"Answer {i}",
                "timestamp": "2024-01-01T00:00:01"
            })
        
        return history
    
    @staticmethod
    def generate_mock_results(n=3):
        """Générer des résultats RAG mock"""
        results = []
        
        for i in range(n):
            results.append({
                'text': f'Question: Mock Q{i}\n\nRéponse: Mock A{i}',
                'similarity': 0.9 - (i * 0.1),
                'metadata': {'index': i}
            })
        
        return results

# ============================================================================
# EXÉCUTION DES TESTS
# ============================================================================

if __name__ == "__main__":
    print("\n" + "="*70)
    print("🧪 EXÉCUTION DES TESTS")
    print("="*70 + "\n")
    
    # Lancer pytest
    pytest.main([
        __file__,
        "-v",  # Verbose
        "--tb=short",  # Traceback court
        "--color=yes"  # Couleurs
    ])
