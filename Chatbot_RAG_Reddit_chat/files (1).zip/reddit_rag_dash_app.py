"""
Reddit RAG Chatbot - Application Dash Interactive
Application web professionnelle pour interagir avec le système RAG Reddit
"""

import dash
from dash import dcc, html, Input, Output, State, callback_context, ALL
import dash_bootstrap_components as dbc
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import json
import time
from datetime import datetime
from typing import List, Dict
import os

# Imports du système RAG
try:
    from reddit_rag_optimized import OptimizedRedditRAG
    RAG_AVAILABLE = True
except ImportError:
    RAG_AVAILABLE = False
    print("⚠️ Module reddit_rag_optimized non trouvé")

try:
    from llm_generator import LLM_AVAILABLE
except ImportError:
    LLM_AVAILABLE = False

# Configuration de l'application
app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.CYBORG, dbc.icons.FONT_AWESOME],
    suppress_callback_exceptions=True
)

app.title = "Reddit RAG Chatbot"

# ============================================================================
# CONSTANTES ET CONFIGURATION
# ============================================================================

THEMES = {
    'dark': {
        'background': '#0a0e27',
        'card': 'rgba(20, 25, 45, 0.95)',
        'text': '#e0e0e0',
        'primary': '#00d4ff',
        'secondary': '#9d4edd',
        'success': '#06ffa5',
        'warning': '#ffbe0b',
        'danger': '#ff006e'
    },
    'light': {
        'background': '#f8f9fa',
        'card': 'rgba(255, 255, 255, 0.95)',
        'text': '#212529',
        'primary': '#0077b6',
        'secondary': '#6c757d',
        'success': '#06d6a0',
        'warning': '#ffd166',
        'danger': '#ef476f'
    }
}

CURRENT_THEME = THEMES['dark']

EXAMPLE_QUESTIONS = [
    "What's the best phone to buy?",
    "How do I stay motivated?",
    "What should I do when feeling sad?",
    "Best advice for learning programming?",
    "How to make new friends?",
    "What are good movies to watch?",
    "How to start working out?",
    "Best diet for weight loss?",
    "Tips for better sleep?",
    "What laptop is good for students?"
]

# ============================================================================
# COMPOSANTS UI
# ============================================================================

def create_header():
    """Créer l'en-tête de l'application"""
    return html.Div([
        dbc.Row([
            dbc.Col([
                html.Div([
                    html.I(className="fas fa-robot me-3", 
                          style={"fontSize": "2.5rem", "color": CURRENT_THEME['primary']}),
                    html.Div([
                        html.H1("Reddit RAG Chatbot", 
                               style={"color": CURRENT_THEME['primary'], "marginBottom": "0"}),
                        html.P("Intelligence conversationnelle basée sur Reddit", 
                              className="text-muted mb-0")
                    ])
                ], className="d-flex align-items-center")
            ], width=8),
            dbc.Col([
                html.Div([
                    dbc.Badge([
                        html.I(className="fas fa-database me-2"),
                        "RAG System"
                    ], color="primary", className="me-2 p-2"),
                    dbc.Badge([
                        html.I(className="fas fa-brain me-2"),
                        "AI Powered"
                    ], color="success", className="p-2"),
                ], className="text-end")
            ], width=4)
        ], className="mb-4")
    ], style={
        "background": f"linear-gradient(135deg, {CURRENT_THEME['card']}, {CURRENT_THEME['background']})",
        "padding": "30px",
        "borderRadius": "15px",
        "marginBottom": "30px",
        "boxShadow": "0 8px 32px rgba(0, 212, 255, 0.15)"
    })

def create_sidebar():
    """Créer la barre latérale avec les paramètres"""
    return dbc.Card([
        dbc.CardHeader([
            html.I(className="fas fa-sliders-h me-2"),
            html.Strong("Paramètres de Recherche")
        ], style={"backgroundColor": CURRENT_THEME['primary'], "color": "#000"}),
        dbc.CardBody([
            # Nombre de résultats
            html.Label([
                html.I(className="fas fa-list-ol me-2"),
                "Nombre de résultats"
            ], className="mb-2"),
            dcc.Slider(
                id="num-results-slider",
                min=1, max=10, value=3, step=1,
                marks={i: str(i) for i in range(1, 11)},
                tooltip={"placement": "bottom", "always_visible": False}
            ),
            
            html.Hr(),
            
            # Optimisations
            html.Label([
                html.I(className="fas fa-magic me-2"),
                "Optimisations"
            ], className="mb-3"),
            
            dbc.Checklist(
                options=[
                    {"label": " Re-classement des résultats", "value": "rerank"},
                    {"label": " Diversification", "value": "diversity"},
                    {"label": " Recherche hybride", "value": "hybrid"},
                ],
                value=["rerank", "diversity"],
                id="optimization-checklist",
                switch=True,
                className="mb-3"
            ),
            
            html.Hr(),
            
            # Mode LLM
            html.Label([
                html.I(className="fas fa-brain me-2"),
                "Mode Génératif"
            ], className="mb-3"),
            
            dbc.Checklist(
                options=[{"label": " Activer le LLM", "value": "llm"}],
                value=[],
                id="llm-toggle",
                switch=True,
                className="mb-3"
            ),
            
            html.Label("Température", className="mb-2"),
            dcc.Slider(
                id="temperature-slider",
                min=0.1, max=1.0, value=0.7, step=0.1,
                marks={i/10: f"{i/10:.1f}" for i in range(1, 11)},
                disabled=True
            ),
            
            html.Hr(),
            
            # Filtres
            html.Label([
                html.I(className="fas fa-filter me-2"),
                "Filtres de longueur"
            ], className="mb-3"),
            
            html.Label("Longueur minimale", className="small mb-1"),
            dcc.Input(
                id="min-length-input",
                type="number",
                value=0,
                min=0,
                max=1000,
                className="form-control mb-2"
            ),
            
            html.Label("Longueur maximale", className="small mb-1"),
            dcc.Input(
                id="max-length-input",
                type="number",
                value=5000,
                min=500,
                max=5000,
                className="form-control mb-3"
            ),
            
            html.Hr(),
            
            # Boutons d'action
            dbc.Button([
                html.I(className="fas fa-broom me-2"),
                "Effacer la conversation"
            ], id="clear-chat-btn", color="danger", className="w-100 mb-2"),
            
            dbc.Button([
                html.I(className="fas fa-download me-2"),
                "Exporter JSON"
            ], id="export-json-btn", color="secondary", className="w-100"),
        ])
    ], className="glass-card mb-3", style={"position": "sticky", "top": "20px"})

def create_chat_interface():
    """Créer l'interface de chat principale"""
    return dbc.Card([
        dbc.CardHeader([
            html.I(className="fas fa-comments me-2"),
            html.Strong("Conversation"),
            dbc.Badge("0", id="message-counter", color="info", className="ms-2")
        ]),
        dbc.CardBody([
            # Zone de messages
            html.Div(id="chat-messages", children=[], style={
                "height": "500px",
                "overflowY": "auto",
                "padding": "20px",
                "backgroundColor": "rgba(0,0,0,0.2)",
                "borderRadius": "10px"
            }),
            
            # Zone de saisie
            html.Div([
                dbc.InputGroup([
                    dbc.Input(
                        id="user-input",
                        placeholder="Posez votre question ici...",
                        type="text",
                        className="form-control-lg",
                        style={"borderRadius": "20px 0 0 20px"}
                    ),
                    dbc.Button([
                        html.I(className="fas fa-paper-plane")
                    ], id="send-btn", color="primary", 
                    style={"borderRadius": "0 20px 20px 0"})
                ])
            ], className="mt-3")
        ])
    ], className="glass-card")

def create_stats_panel():
    """Créer le panneau de statistiques"""
    return dbc.Card([
        dbc.CardHeader([
            html.I(className="fas fa-chart-line me-2"),
            html.Strong("Statistiques en temps réel")
        ]),
        dbc.CardBody([
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.I(className="fas fa-clock fa-2x mb-2", 
                              style={"color": CURRENT_THEME['primary']}),
                        html.H4("0 ms", id="avg-time-stat"),
                        html.Small("Temps moyen", className="text-muted")
                    ], className="text-center")
                ], width=4),
                dbc.Col([
                    html.Div([
                        html.I(className="fas fa-search fa-2x mb-2", 
                              style={"color": CURRENT_THEME['success']}),
                        html.H4("0", id="total-queries-stat"),
                        html.Small("Requêtes totales", className="text-muted")
                    ], className="text-center")
                ], width=4),
                dbc.Col([
                    html.Div([
                        html.I(className="fas fa-bolt fa-2x mb-2", 
                              style={"color": CURRENT_THEME['warning']}),
                        html.H4("0%", id="cache-hit-stat"),
                        html.Small("Cache hit rate", className="text-muted")
                    ], className="text-center")
                ], width=4),
            ])
        ])
    ], className="glass-card mb-3")

def create_quality_panel():
    """Créer le panneau d'évaluation de qualité"""
    return dbc.Card([
        dbc.CardHeader([
            html.I(className="fas fa-star me-2"),
            html.Strong("Qualité de la recherche")
        ]),
        dbc.CardBody([
            html.Div(id="quality-content", children=[
                html.P("Aucune recherche effectuée", className="text-muted text-center")
            ])
        ])
    ], className="glass-card mb-3")

def create_examples_panel():
    """Créer le panneau des exemples de questions"""
    return dbc.Card([
        dbc.CardHeader([
            html.I(className="fas fa-lightbulb me-2"),
            html.Strong("Questions suggérées")
        ]),
        dbc.CardBody([
            html.Div([
                dbc.Button(
                    question,
                    id={"type": "example-btn", "index": i},
                    color="outline-primary",
                    size="sm",
                    className="mb-2 w-100 text-start"
                ) for i, question in enumerate(EXAMPLE_QUESTIONS[:5])
            ])
        ])
    ], className="glass-card")

# ============================================================================
# LAYOUT PRINCIPAL
# ============================================================================

app.layout = dbc.Container([
    # Stores pour la persistance
    dcc.Store(id="chat-history", storage_type="session", data=[]),
    dcc.Store(id="rag-stats", storage_type="memory", data={
        "total_queries": 0,
        "avg_time": 0,
        "cache_hits": 0
    }),
    dcc.Store(id="rag-system-ready", storage_type="memory", data=False),
    dcc.Download(id="download-json"),
    
    # Header
    create_header(),
    
    # Contenu principal
    dbc.Row([
        # Sidebar
        dbc.Col([
            create_sidebar(),
            create_examples_panel()
        ], width=3),
        
        # Zone centrale
        dbc.Col([
            create_chat_interface(),
        ], width=6),
        
        # Panneau droit
        dbc.Col([
            create_stats_panel(),
            create_quality_panel()
        ], width=3),
    ]),
    
    # Footer
    html.Div([
        html.Hr(),
        html.P([
            html.I(className="fas fa-info-circle me-2"),
            "Système RAG basé sur des conversations Reddit réelles | ",
            html.A("Documentation", href="#", className="text-primary")
        ], className="text-center text-muted small")
    ], className="mt-5")
    
], fluid=True, style={
    "backgroundColor": CURRENT_THEME['background'],
    "minHeight": "100vh",
    "padding": "30px"
})

# ============================================================================
# CALLBACKS
# ============================================================================

# Initialiser le système RAG au démarrage
@app.callback(
    Output("rag-system-ready", "data"),
    Input("rag-system-ready", "data")
)
def initialize_rag_system(current_state):
    """Initialiser le système RAG"""
    if current_state:
        return current_state
    
    if not RAG_AVAILABLE:
        print("❌ Système RAG non disponible")
        return False
    
    try:
        global rag_system
        rag_system = OptimizedRedditRAG()
        rag_system.load('reddit_optimized_rag')
        print("✅ Système RAG chargé avec succès")
        return True
    except Exception as e:
        print(f"❌ Erreur lors du chargement du RAG: {e}")
        return False

# Activer/désactiver la température selon le mode LLM
@app.callback(
    Output("temperature-slider", "disabled"),
    Input("llm-toggle", "value")
)
def toggle_temperature(llm_enabled):
    """Activer la température seulement si LLM est activé"""
    return "llm" not in (llm_enabled or [])

# Gérer l'envoi de messages
@app.callback(
    [Output("chat-messages", "children"),
     Output("user-input", "value"),
     Output("chat-history", "data"),
     Output("message-counter", "children"),
     Output("quality-content", "children"),
     Output("rag-stats", "data")],
    [Input("send-btn", "n_clicks"),
     Input("user-input", "n_submit"),
     Input({"type": "example-btn", "index": ALL}, "n_clicks")],
    [State("user-input", "value"),
     State("chat-history", "data"),
     State("num-results-slider", "value"),
     State("optimization-checklist", "value"),
     State("llm-toggle", "value"),
     State("temperature-slider", "value"),
     State("min-length-input", "value"),
     State("max-length-input", "value"),
     State("rag-system-ready", "data"),
     State("rag-stats", "data"),
     State({"type": "example-btn", "index": ALL}, "id")]
)
def handle_message(send_click, enter_submit, example_clicks, user_message, 
                  chat_history, num_results, optimizations, llm_toggle,
                  temperature, min_length, max_length, system_ready,
                  stats, example_ids):
    """Traiter les messages de l'utilisateur"""
    
    # Vérifier quel bouton a déclenché le callback
    ctx = callback_context
    if not ctx.triggered:
        return chat_history or [], "", chat_history or [], "0", html.P("Aucune recherche", className="text-muted"), stats
    
    triggered_id = ctx.triggered[0]["prop_id"].split(".")[0]
    
    # Si c'est un bouton d'exemple
    if "example-btn" in triggered_id:
        # Trouver quel bouton a été cliqué
        for i, click in enumerate(example_clicks):
            if click:
                user_message = EXAMPLE_QUESTIONS[i]
                break
    
    # Si pas de message, ne rien faire
    if not user_message or not user_message.strip():
        return chat_history or [], "", chat_history or [], str(len(chat_history or [])), html.P("Aucune recherche", className="text-muted"), stats
    
    # Vérifier si le système est prêt
    if not system_ready:
        error_msg = create_message("system", "⚠️ Système RAG non disponible. Veuillez recharger la page.", error=True)
        return [error_msg], "", chat_history or [], "0", html.P("Erreur système", className="text-danger"), stats
    
    # Ajouter le message utilisateur
    chat_history = chat_history or []
    user_msg = create_message("user", user_message)
    chat_history.append({"role": "user", "content": user_message, "timestamp": datetime.now().isoformat()})
    
    # Préparer les paramètres
    use_rerank = "rerank" in (optimizations or [])
    use_diversity = "diversity" in (optimizations or [])
    use_hybrid = "hybrid" in (optimizations or [])
    use_llm = "llm" in (llm_toggle or [])
    
    filters = {}
    if min_length and min_length > 0:
        filters['min_length'] = min_length
    if max_length and max_length < 5000:
        filters['max_length'] = max_length
    
    # Effectuer la recherche
    try:
        start_time = time.time()
        
        if use_llm and LLM_AVAILABLE and hasattr(rag_system, 'llm_enabled') and rag_system.llm_enabled:
            # Mode LLM
            result = rag_system.generate_response(
                query=user_message,
                top_k=num_results,
                temperature=temperature,
                verbose=False
            )
            response_text = result['response']
            search_time = result['timing']['total_ms']
            quality = result['context_quality']
            
        else:
            # Mode RAG classique
            result = rag_system.optimized_search(
                query=user_message,
                top_k=num_results,
                use_reranking=use_rerank,
                use_diversity=use_diversity,
                use_hybrid=use_hybrid,
                filters=filters if filters else None
            )
            
            search_time = result['timing']['total'] * 1000
            quality = result['quality']
            
            # Formater la réponse
            response_text = format_rag_results(result['results'])
        
        # Créer le message de réponse
        assistant_msg = create_message("assistant", response_text)
        chat_history.append({
            "role": "assistant", 
            "content": response_text,
            "timestamp": datetime.now().isoformat(),
            "search_time": search_time,
            "quality": quality
        })
        
        # Mettre à jour les stats
        stats['total_queries'] = stats.get('total_queries', 0) + 1
        stats['avg_time'] = ((stats.get('avg_time', 0) * (stats['total_queries'] - 1)) + search_time) / stats['total_queries']
        stats['cache_hits'] = getattr(rag_system, 'stats', {}).get('cache_hits', 0)
        
        # Créer le panneau de qualité
        quality_panel = create_quality_display(quality, search_time)
        
        # Messages complets
        messages = [user_msg, assistant_msg]
        
        return messages, "", chat_history, str(len(chat_history)), quality_panel, stats
        
    except Exception as e:
        error_msg = create_message("system", f"❌ Erreur: {str(e)}", error=True)
        return [user_msg, error_msg], "", chat_history, str(len(chat_history)), html.P("Erreur", className="text-danger"), stats

def create_message(role, content, error=False):
    """Créer un message formaté"""
    if role == "user":
        return html.Div([
            html.Div([
                html.I(className="fas fa-user-circle fa-2x me-3"),
                html.Div([
                    html.Strong("Vous", className="mb-1"),
                    html.P(content, className="mb-0")
                ])
            ], className="d-flex align-items-start")
        ], style={
            "backgroundColor": "rgba(0, 212, 255, 0.1)",
            "padding": "15px",
            "borderRadius": "15px",
            "marginBottom": "15px",
            "marginLeft": "20%",
            "border": f"2px solid {CURRENT_THEME['primary']}"
        })
    
    elif role == "assistant":
        return html.Div([
            html.Div([
                html.I(className="fas fa-robot fa-2x me-3", 
                      style={"color": CURRENT_THEME['success']}),
                html.Div([
                    html.Strong("Assistant", className="mb-1", 
                              style={"color": CURRENT_THEME['success']}),
                    dcc.Markdown(content, className="mb-0")
                ])
            ], className="d-flex align-items-start")
        ], style={
            "backgroundColor": "rgba(6, 255, 165, 0.1)",
            "padding": "15px",
            "borderRadius": "15px",
            "marginBottom": "15px",
            "marginRight": "20%",
            "border": f"2px solid {CURRENT_THEME['success']}"
        })
    
    else:  # system
        color = CURRENT_THEME['danger'] if error else CURRENT_THEME['warning']
        return html.Div([
            html.I(className="fas fa-exclamation-triangle me-2"),
            html.Span(content)
        ], style={
            "backgroundColor": f"rgba(255, 0, 110, 0.1)" if error else "rgba(255, 190, 11, 0.1)",
            "padding": "10px",
            "borderRadius": "10px",
            "marginBottom": "10px",
            "border": f"1px solid {color}",
            "color": color
        })

def format_rag_results(results):
    """Formater les résultats RAG en Markdown"""
    if not results:
        return "❌ Aucun résultat trouvé."
    
    formatted = "### Voici ce que j'ai trouvé :\n\n"
    
    for i, result in enumerate(results, 1):
        similarity = result['similarity'] * 100
        text = result['text']
        
        # Icône selon la pertinence
        if similarity >= 90:
            icon = "🎯"
        elif similarity >= 80:
            icon = "✅"
        elif similarity >= 70:
            icon = "👍"
        else:
            icon = "📌"
        
        # Extraire question/réponse
        if "Question:" in text and "Réponse:" in text:
            parts = text.split("Réponse:", 1)
            question = parts[0].replace("Question:", "").strip()
            answer = parts[1].strip() if len(parts) > 1 else ""
            
            formatted += f"""
**{icon} Résultat {i}** (Pertinence: {similarity:.1f}%)

> **Q:** {question}

**R:** {answer}

---

"""
        else:
            formatted += f"""
**{icon} Résultat {i}** (Pertinence: {similarity:.1f}%)

{text}

---

"""
    
    return formatted

def create_quality_display(quality, search_time):
    """Créer l'affichage de qualité"""
    quality_emoji = {
        'excellent': '🌟',
        'good': '✅',
        'fair': '👍',
        'poor': '⚠️'
    }
    
    quality_color = {
        'excellent': CURRENT_THEME['success'],
        'good': CURRENT_THEME['primary'],
        'fair': CURRENT_THEME['warning'],
        'poor': CURRENT_THEME['danger']
    }
    
    qual_level = quality.get('quality', 'fair')
    
    return html.Div([
        html.H5([
            quality_emoji.get(qual_level, '📊'),
            f" {qual_level.upper()}"
        ], style={"color": quality_color.get(qual_level)}),
        
        html.Hr(),
        
        html.Div([
            html.Small("Confiance:", className="text-muted me-2"),
            dbc.Progress(value=quality.get('confidence', 0)*100, 
                        color="info", className="mb-2"),
        ]),
        
        html.Div([
            html.Small("Diversité:", className="text-muted me-2"),
            dbc.Progress(value=quality.get('diversity', 0)*100, 
                        color="success", className="mb-2"),
        ]),
        
        html.Div([
            html.Small("Couverture:", className="text-muted me-2"),
            dbc.Progress(value=quality.get('coverage', 0)*100, 
                        color="warning", className="mb-2"),
        ]),
        
        html.Hr(),
        
        html.P([
            html.I(className="fas fa-clock me-2"),
            f"Temps: {search_time:.1f} ms"
        ], className="small text-muted mb-0")
    ])

# Mettre à jour les statistiques
@app.callback(
    [Output("avg-time-stat", "children"),
     Output("total-queries-stat", "children"),
     Output("cache-hit-stat", "children")],
    Input("rag-stats", "data")
)
def update_stats(stats):
    """Mettre à jour l'affichage des statistiques"""
    avg_time = f"{stats.get('avg_time', 0):.1f} ms"
    total = str(stats.get('total_queries', 0))
    
    # Calculer le cache hit rate
    cache_rate = 0
    if stats.get('total_queries', 0) > 0:
        cache_rate = (stats.get('cache_hits', 0) / stats['total_queries']) * 100
    
    cache_hit = f"{cache_rate:.1f}%"
    
    return avg_time, total, cache_hit

# Effacer la conversation
@app.callback(
    [Output("chat-messages", "children", allow_duplicate=True),
     Output("chat-history", "data", allow_duplicate=True),
     Output("message-counter", "children", allow_duplicate=True)],
    Input("clear-chat-btn", "n_clicks"),
    prevent_initial_call=True
)
def clear_chat(n_clicks):
    """Effacer l'historique de conversation"""
    if n_clicks:
        return [], [], "0"
    return dash.no_update

# Exporter en JSON
@app.callback(
    Output("download-json", "data"),
    Input("export-json-btn", "n_clicks"),
    State("chat-history", "data"),
    prevent_initial_call=True
)
def export_conversation(n_clicks, chat_history):
    """Exporter la conversation en JSON"""
    if n_clicks and chat_history:
        export_data = {
            'timestamp': datetime.now().isoformat(),
            'conversation': chat_history,
            'total_messages': len(chat_history)
        }
        
        return dict(
            content=json.dumps(export_data, indent=2, ensure_ascii=False),
            filename=f"reddit_chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        )
    return dash.no_update

# ============================================================================
# POINT D'ENTRÉE
# ============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Reddit RAG Chatbot - Application Dash")
    parser.add_argument("--port", type=int, default=8050, help="Port du serveur")
    parser.add_argument("--debug", action="store_true", help="Mode debug")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Host du serveur")
    
    args = parser.parse_args()
    
    print("="*70)
    print("🚀 REDDIT RAG CHATBOT - APPLICATION DASH")
    print("="*70)
    print(f"\n📍 URL: http://{args.host}:{args.port}")
    print(f"🔧 Debug: {'Activé' if args.debug else 'Désactivé'}")
    print("\n💡 Appuyez sur Ctrl+C pour arrêter\n")
    
    app.run(
        debug=args.debug,
        host=args.host,
        port=args.port
    )
